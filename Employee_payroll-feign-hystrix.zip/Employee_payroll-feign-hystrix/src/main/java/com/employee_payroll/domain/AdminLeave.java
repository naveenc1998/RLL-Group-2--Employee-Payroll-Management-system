package com.employee_payroll.domain;

public class AdminLeave {

	
	private int id;

	
	private String from_date;

	
	private String to_date;

	
	private String leave_type;

	
	private String reason;

	
	private String status;

	
	private int empid;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFrom_date() {
		return from_date;
	}

	public void setFrom_date(String from_date) {
		this.from_date = from_date;
	}

	public String getTo_date() {
		return to_date;
	}

	public void setTo_date(String to_date) {
		this.to_date = to_date;
	}

	public String getLeave_type() {
		return leave_type;
	}

	public void setLeave_type(String leave_type) {
		this.leave_type = leave_type;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public AdminLeave(int id, String from_date, String to_date, String leave_type, String reason, String status,
			int empid) {
		super();
		this.id = id;
		this.from_date = from_date;
		this.to_date = to_date;
		this.leave_type = leave_type;
		this.reason = reason;
		this.status = status;
		this.empid = empid;
	}

	public AdminLeave() {
		super();
		
	}

	@Override
	public String toString() {
		return "AdminLeave [id=" + id + ", from_date=" + from_date + ", to_date=" + to_date + ", leave_type="
				+ leave_type + ", reason=" + reason + ", status=" + status + ", empid=" + empid + "]";
	}
	
	
	

}
