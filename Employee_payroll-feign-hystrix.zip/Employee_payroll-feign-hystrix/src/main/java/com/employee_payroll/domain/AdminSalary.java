package com.employee_payroll.domain;

public class AdminSalary {
	
	private long id;

	
	private String emp_name;

	
	private String basic_pay;

	
	private String deductions;

	
	private String net_pay;

	
	private String month;

	public AdminSalary() {

	}

	public AdminSalary(long id, String emp_name, String basic_pay, String deductions, String net_pay, String month) {
		super();
		this.id = id;
		this.emp_name = emp_name;
		this.basic_pay = basic_pay;
		this.deductions = deductions;
		this.net_pay = net_pay;
		this.month = month;
	}

	public long getid() {
		return id;
	}

	public void setid(long id) {
		this.id = id;
	}

	public String getEmp_name() {
		return emp_name;
	}

	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}

	public String getBasic_pay() {
		return basic_pay;
	}

	public void setBasic_pay(String basic_pay) {
		this.basic_pay = basic_pay;
	}

	public String getDeductions() {
		return deductions;
	}

	public void setDeductions(String deductions) {
		this.deductions = deductions;
	}

	public String getNet_pay() {
		return net_pay;
	}

	public void setNet_pay(String net_pay) {
		this.net_pay = net_pay;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

}
