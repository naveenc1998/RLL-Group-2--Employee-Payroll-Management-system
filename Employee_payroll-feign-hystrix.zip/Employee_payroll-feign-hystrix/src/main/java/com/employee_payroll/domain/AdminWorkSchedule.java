package com.employee_payroll.domain;


public class AdminWorkSchedule {

	
	private long id;


	private String emp_name;
	
	
	private String workdate;

	
	private String worktime;

	
	private String workshift;

	
	private String workstatus;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getEmp_name() {
		return emp_name;
	}

	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}

	public String getWorkdate() {
		return workdate;
	}

	public void setWorkdate(String workdate) {
		this.workdate = workdate;
	}

	public String getWorktime() {
		return worktime;
	}

	public void setWorktime(String worktime) {
		this.worktime = worktime;
	}

	public String getWorkshift() {
		return workshift;
	}

	public void setWorkshift(String workshift) {
		this.workshift = workshift;
	}

	public String getWorkstatus() {
		return workstatus;
	}

	public void setWorkstatus(String workstatus) {
		this.workstatus = workstatus;
	}

	public AdminWorkSchedule(long id, String emp_name, String workdate, String worktime, String workshift,
			String workstatus) {
		super();
		this.id = id;
		this.emp_name = emp_name;
		this.workdate = workdate;
		this.worktime = worktime;
		this.workshift = workshift;
		this.workstatus = workstatus;
	}

	public AdminWorkSchedule() {
		super();
		
	}
	
	
	
	
	
	
}
