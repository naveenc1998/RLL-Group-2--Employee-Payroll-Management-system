package com.employee_payroll.proxy;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import com.employee_payroll.domain.Employee;
import com.employee_payroll.fallback.EmployeeFallback;


@FeignClient(name="Employee-service",fallback=EmployeeFallback.class)
public interface EmployeeProxy {
    

	@GetMapping("/employees")
	public List<Employee> getAllEmployees(); 

	@GetMapping("/employees/{empid}")
	public Employee getEmployeeById(@PathVariable("empid") int employeeId);
	
	
	
}
