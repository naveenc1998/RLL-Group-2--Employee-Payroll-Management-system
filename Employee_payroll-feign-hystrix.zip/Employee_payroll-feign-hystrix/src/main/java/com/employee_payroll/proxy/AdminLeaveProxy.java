package com.employee_payroll.proxy;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.employee_payroll.domain.AdminLeave;
import com.employee_payroll.fallback.AdminLeaveFallback;


@FeignClient(name="AdminLeave-service",fallback=AdminLeaveFallback.class)
public interface AdminLeaveProxy {
    

	
	@GetMapping("/leaves")
	public List<AdminLeave> getAllLeave();

	@GetMapping("/leaves/{id}")
	public AdminLeave getLeaveById(@PathVariable int id);
	
	
	
	
}
