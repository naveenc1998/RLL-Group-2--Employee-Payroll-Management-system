package com.employee_payroll.proxy;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.employee_payroll.domain.AdminWorkSchedule;
import com.employee_payroll.fallback.AdminWorkScheduleFallback;

@FeignClient(name="AdminWorkSchedule-service",fallback=AdminWorkScheduleFallback.class)
public interface AdminWorkScheduleProxy {
    
	
	
	@GetMapping("/schedules")
	public List<AdminWorkSchedule> getAllWork();
    
	@GetMapping("/schedules/{id}")
	public AdminWorkSchedule getWorkById(@PathVariable("id") long id);
      

	
}
