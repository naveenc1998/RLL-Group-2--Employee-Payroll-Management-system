package com.employee_payroll.proxy;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.employee_payroll.domain.AdminSalary;
import com.employee_payroll.fallback.AdminSalaryFallback;




@FeignClient(name="AdminSalary-service",fallback=AdminSalaryFallback.class)
public interface AdminSalaryProxy {
    

	
	@GetMapping("/salarys")
	public List<AdminSalary> getAllSalary();

	@GetMapping("/salarys/{id}")
	public AdminSalary getSalaryById(@PathVariable("id") long employeeId);
	
	
}
