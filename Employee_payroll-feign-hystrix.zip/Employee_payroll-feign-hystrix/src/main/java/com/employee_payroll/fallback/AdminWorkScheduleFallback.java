package com.employee_payroll.fallback;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;

import com.employee_payroll.domain.AdminWorkSchedule;
import com.employee_payroll.proxy.AdminWorkScheduleProxy;


@Component
public class AdminWorkScheduleFallback implements AdminWorkScheduleProxy{

	

	@Override
	public List<AdminWorkSchedule> getAllWork() {
		
		return Arrays.asList(new AdminWorkSchedule());
	}

	@Override
	public AdminWorkSchedule getWorkById(@PathVariable("id") long id){
		
		return  new AdminWorkSchedule(0,"suprith","2007-05-07","nine","night","working");
	}

	
	

}
