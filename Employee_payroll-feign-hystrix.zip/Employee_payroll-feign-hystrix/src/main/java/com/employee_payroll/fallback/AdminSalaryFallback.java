package com.employee_payroll.fallback;

import java.util.Arrays;
import java.util.List;


import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;
import com.employee_payroll.domain.AdminSalary;
import com.employee_payroll.proxy.AdminSalaryProxy;


@Component
public class AdminSalaryFallback implements AdminSalaryProxy{

	@Override
	public List<AdminSalary> getAllSalary() {
		
		return  Arrays.asList(new AdminSalary());
	}

	@Override
	public AdminSalary getSalaryById(@PathVariable("id") long employeeId) {
		
		return new AdminSalary(0,"naveen1"," 2 thousand","1 thousand","5 thosand","nov");
	}

	
	
	

}
