package com.employee_payroll.fallback;

import java.util.Arrays;
import java.util.List;


import org.springframework.stereotype.Component;
import com.employee_payroll.domain.Employee;
import com.employee_payroll.proxy.EmployeeProxy;


@Component
public class EmployeeFallback implements EmployeeProxy{

	@Override
	public List<Employee> getAllEmployees() {
		
		return  Arrays.asList(new Employee());
	}

	@Override
	public Employee getEmployeeById(int employeeId) {
		
		return new Employee(0,"suprith","2021-12-16","male",25,"CSE","suprith@gmail.com","789456123");
	}

	
	
	
	

}
