package com.employee_payroll.fallback;

import java.util.Arrays;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.PathVariable;

import com.employee_payroll.domain.AdminLeave;

import com.employee_payroll.proxy.AdminLeaveProxy;


@Component
public class AdminLeaveFallback implements AdminLeaveProxy{

	@Override
	public List<AdminLeave> getAllLeave() {
		
		return  Arrays.asList(new AdminLeave());
	}

	@Override
	public AdminLeave getLeaveById(@PathVariable int id) {
		
		return new AdminLeave(1, "2000-02-22","2000-02-26", "in", "outStation", "present",1);
	}


	
	

}
