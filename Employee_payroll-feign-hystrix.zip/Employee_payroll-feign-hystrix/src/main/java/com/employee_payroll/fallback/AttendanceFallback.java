package com.employee_payroll.fallback;

import java.util.Arrays;
import java.util.List;


import org.springframework.stereotype.Component;
import com.employee_payroll.domain.AdminAttendance;
import com.employee_payroll.proxy.AttendanceProxy;


@Component
public class AttendanceFallback implements AttendanceProxy{

	@Override
	public List<AdminAttendance> getAllAdmins() {
		
		return Arrays.asList(new AdminAttendance());
	}

	@Override
	public AdminAttendance getAttendanceById(int employeeId) {
		
		return new AdminAttendance(0,"suprith","suprith@gmail.com","2009-09-08","present",1);
	}

	
	

}
