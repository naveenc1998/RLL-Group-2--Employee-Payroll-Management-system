package com.employee_payroll.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.employee_payroll.domain.AdminLeave;
import com.employee_payroll.domain.AdminWorkSchedule;
import com.employee_payroll.proxy.AdminLeaveProxy;
import com.employee_payroll.proxy.AdminWorkScheduleProxy;

@RestController
@Scope("request")
public class AdminLeaveController {
    
	@Autowired
       AdminLeaveProxy adminLeaveProxy;
	
	

	@GetMapping("/leaves")
	public List<AdminLeave> getAllLeave(){
		List<AdminLeave> allLeave = adminLeaveProxy.getAllLeave();
		return allLeave;
		
	}

	@GetMapping("/leaves/{id}")
	public AdminLeave getLeaveById(@PathVariable int id) {
	
			AdminLeave leaveById = adminLeaveProxy.getLeaveById(id);
			return leaveById;
	}	
		 
	
}
	
	
	
	
	
	
	
	
	
	

