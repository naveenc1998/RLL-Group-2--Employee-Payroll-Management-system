package com.employee_payroll.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.employee_payroll.domain.AdminAttendance;
import com.employee_payroll.domain.AdminLeave;
import com.employee_payroll.domain.AdminWorkSchedule;
import com.employee_payroll.proxy.AdminLeaveProxy;
import com.employee_payroll.proxy.AdminWorkScheduleProxy;
import com.employee_payroll.proxy.AttendanceProxy;

@RestController
@Scope("request")
public class AttendanceController {
    
	@Autowired
      AttendanceProxy attendanceProxy;
	
	

	@GetMapping("/attendances")
	public List<AdminAttendance> getAllAdmins(){
		List<AdminAttendance> allAdmins = attendanceProxy.getAllAdmins();
		 return allAdmins;
	}

	@GetMapping("/attendances/{id}")
	public AdminAttendance  getAttendanceById(@PathVariable("id") int employeeId) {
		AdminAttendance attendanceById = attendanceProxy.getAttendanceById(employeeId);
		    return attendanceById;
	}

		 
	
}
	
	
	
	
	
	
	
	
	
	

