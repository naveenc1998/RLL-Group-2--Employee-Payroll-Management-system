package com.employee_payroll.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import com.employee_payroll.domain.Employee;
import com.employee_payroll.proxy.EmployeeProxy;

@RestController
@Scope("request")
public class EmployeeController {
    
	@Autowired
       EmployeeProxy employeeProxy;
	

	@GetMapping("/employees")
	public List<Employee> getAllEmployees(){
		List<Employee> allEmployees = employeeProxy.getAllEmployees();
		return allEmployees;
	} 

	@GetMapping("/employees/{empid}")
	public Employee getEmployeeById(@PathVariable("empid") int employeeId) {
		Employee employeeById = employeeProxy.getEmployeeById(employeeId);
		    return employeeById;
	}
	
	
		 
	
}
	
	
	
	
	
	
	
	
	
	

