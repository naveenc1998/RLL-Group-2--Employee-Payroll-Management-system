INSERT INTO epms.Admin_Work_Schedule(id,emp_name,work_date,work_time,work_shift,work_status) VALUES('niranjan','2022-04-19','nine','night','working'); 

INSERT INTO epms.Admin_Work_Schedule(id,emp_name,work_date,work_time,work_shift,work_status) VALUES('arun','2021-06-12','six','day','working');

INSERT INTO epms.Admin_Work_Schedule(id,emp_name,work_date,work_time,work_shift,work_status) VALUES('rakesh','2012-07-1','eight','night','leave');

INSERT INTO epms.Admin_Work_Schedule(id,emp_name,work_date,work_time,work_shift,work_status) VALUES('raj','2023-02-6','nine','day','leave');