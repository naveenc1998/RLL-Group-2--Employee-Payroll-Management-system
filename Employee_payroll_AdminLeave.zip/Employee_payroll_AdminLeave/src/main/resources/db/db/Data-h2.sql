INSERT INTO epms.admin_leave(id, from_date, to_date,leave_type, reason,status,empid ) VALUES('09-09-1999','10-09-1999','op','wedding','not working',1); 

INSERT INTO epms.admin_leave(id, from_date, to_date,leave_type, reason,status,empid ) VALUES('09-11-1992','10-11-1992','op','personal work','not working',2); 

INSERT INTO epms.admin_leave(id, from_date, to_date,leave_type, reason,status,empid ) VALUES('15-10-1990','18-10-1990','sl','health issue','not working',3); 

INSERT INTO epms.admin_leave(id, from_date, to_date,leave_type, reason,status,empid ) VALUES('11-09-1998','12-09-1998','cl','fever','not working',4); 

