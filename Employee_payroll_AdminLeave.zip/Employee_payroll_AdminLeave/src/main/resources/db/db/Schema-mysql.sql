USE epms;  

DROP TABLE IF EXISTS admin_leave; 

CREATE TABLE epms.admin_leave ( 

id INT PRIMARY KEY  AUTO_INCREMENT, 

from_date VARCHAR(255), 
 
to_date VARCHAR(255),

leave_type VARCHAR(255),

reason VARCHAR(255),

status VARCHAR(255),

empid  INT
); 