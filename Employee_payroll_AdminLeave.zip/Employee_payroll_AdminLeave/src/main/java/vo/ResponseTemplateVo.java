package vo;

import com.employee_payroll.model.AdminLeave;

public class ResponseTemplateVo {

	private AdminLeave adminLeave;
	
	private Employee employee;

	public AdminLeave getAdminLeave() {
		return adminLeave;
	}

	public void setAdminLeave(AdminLeave adminLeave) {
		this.adminLeave = adminLeave;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	public ResponseTemplateVo(AdminLeave adminLeave, Employee employee) {
		super();
		this.adminLeave = adminLeave;
		this.employee = employee;
	}

	public ResponseTemplateVo() {
		super();
		
	}

	@Override
	public String toString() {
		return "ResponseTemplateVo [adminLeave=" + adminLeave + ", employee=" + employee + "]";
	}
	
	
}
