
package com.employee_payroll;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

import com.employee_payroll.model.AdminLeave;
import com.employee_payroll.repository.AdminLeaveRepository;


@EnableEurekaClient
@EnableAutoConfiguration
@SpringBootApplication
public class SpringBootBackendApplication implements CommandLineRunner {
@Autowired
@Qualifier("adminLeaveRepository")
private AdminLeaveRepository adminLeaveRepository;


@LoadBalanced
@Bean
public RestTemplate restTemplate() {
	return new RestTemplate();
	
}



	public static void main(String[] args) {
		SpringApplication.run(SpringBootBackendApplication.class, args);
	}
	@Override
	public void run(String... args) throws Exception {
adminLeaveRepository.save(new AdminLeave(0, "1999-09-08","1999-09-09", "op", "wedding", "absent",1));
adminLeaveRepository.save(new AdminLeave(0, "2000-10-29","2000-11-04", "sl", "personal work", "absent",1));
adminLeaveRepository.save(new AdminLeave(0, "2003-11-15","2003-12-01", "sl", "not well", "absent",1));
adminLeaveRepository.save(new AdminLeave(0, "2010-12-14","2010-12-25", "op", "travelling", "absent",1));
		
	}
}

