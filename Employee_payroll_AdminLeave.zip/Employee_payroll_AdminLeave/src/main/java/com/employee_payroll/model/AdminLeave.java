package com.employee_payroll.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "admin_leave")
public class AdminLeave {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;

	@Column(name = "from_date")
	private String from_date;

	@Column(name = "to_date")
	private String to_date;

	@Column(name = "leave_type")
	private String leave_type;

	@Column(name = "reason")
	private String reason;

	@Column(name = "status")
	private String status;

	@Column(name = "empid")
	private int empid;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFrom_date() {
		return from_date;
	}

	public void setFrom_date(String from_date) {
		this.from_date = from_date;
	}

	public String getTo_date() {
		return to_date;
	}

	public void setTo_date(String to_date) {
		this.to_date = to_date;
	}

	public String getLeave_type() {
		return leave_type;
	}

	public void setLeave_type(String leave_type) {
		this.leave_type = leave_type;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public AdminLeave(int id, String from_date, String to_date, String leave_type, String reason, String status,
			int empid) {
		super();
		this.id = id;
		this.from_date = from_date;
		this.to_date = to_date;
		this.leave_type = leave_type;
		this.reason = reason;
		this.status = status;
		this.empid = empid;
	}

	public AdminLeave() {
		super();
		
	}

	@Override
	public String toString() {
		return "AdminLeave [id=" + id + ", from_date=" + from_date + ", to_date=" + to_date + ", leave_type="
				+ leave_type + ", reason=" + reason + ", status=" + status + ", empid=" + empid + "]";
	}
	
	
	

}
