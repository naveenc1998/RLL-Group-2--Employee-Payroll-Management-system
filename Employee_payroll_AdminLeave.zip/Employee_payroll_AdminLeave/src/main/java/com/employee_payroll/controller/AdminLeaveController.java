package com.employee_payroll.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.employee_payroll.model.AdminLeave;
import com.employee_payroll.service.AdminLeaveService;

import vo.ResponseTemplateVo;

@RestController
public class AdminLeaveController {

	private AdminLeaveService adminLeaveService;

	public AdminLeaveController(AdminLeaveService adminLeaveService) {
		super();
		this.adminLeaveService = adminLeaveService;
	}

	
	

	@GetMapping("/empWithleaves/{id}")
	public ResponseTemplateVo getEmpWithLeaves(@PathVariable("id") int empid) {
		return adminLeaveService.getEmpWithLeaves(empid);
	}
	
	
	
	
	
	
	
	
	@PostMapping("/leaves")
	public ResponseEntity<AdminLeave> saveAdminLeave(@RequestBody AdminLeave adminLeave) {
		return new ResponseEntity<AdminLeave>(adminLeaveService.saveAdminLeave(adminLeave), HttpStatus.CREATED);
	}

	@GetMapping("/leaves")
	public List<AdminLeave> getAllLeave() {
		return adminLeaveService.getAllLeave();
	}

	@GetMapping("/leaves/{id}")
	public ResponseEntity<AdminLeave> getLeaveById(@PathVariable("id") int employeeId) {
		return new ResponseEntity<AdminLeave>(adminLeaveService.getLeaveById(employeeId), HttpStatus.OK);
	}

	
	@PutMapping(value="/leaves/{id}",produces= MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<AdminLeave> updateLeave(@PathVariable("id") int id, @RequestBody AdminLeave adminLeave) {
		return new ResponseEntity<AdminLeave>(adminLeaveService.updateLeave(adminLeave, id), HttpStatus.OK);
	}

	
	@DeleteMapping("/leaves/{id}")
	public ResponseEntity<String> deleteLeave(@PathVariable("id") int id) {

		adminLeaveService.deleteLeave(id);

		return new ResponseEntity<String>("Leave deleted successfully!.", HttpStatus.OK);
	}

}