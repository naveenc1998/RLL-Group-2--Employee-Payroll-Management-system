package com.employee_payroll.service;

import java.util.List;

import com.employee_payroll.model.AdminLeave;

import vo.ResponseTemplateVo;

public interface AdminLeaveService {
	AdminLeave saveAdminLeave(AdminLeave adminLeave);

	List<AdminLeave> getAllLeave();

	AdminLeave getLeaveById(int id);

	AdminLeave updateLeave(AdminLeave adminLeave, int id);

	void deleteLeave(int id);
	
	ResponseTemplateVo getEmpWithLeaves(int empid);
}