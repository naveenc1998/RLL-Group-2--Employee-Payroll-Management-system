package com.employee_payroll.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.employee_payroll.exception.ResourceNotFoundException;

import com.employee_payroll.model.AdminLeave;
import com.employee_payroll.repository.AdminLeaveRepository;


import vo.Employee;
import vo.ResponseTemplateVo;

@Service
public class AdminLeaveImpl implements AdminLeaveService {

	private AdminLeaveRepository adminLeaveRepository;
	
	@Autowired
	private RestTemplate restTemplate;

	public ResponseTemplateVo getEmpWithLeaves(int empid) {
		
		  ResponseTemplateVo vo= new ResponseTemplateVo();
		  
		  AdminLeave adminLeave = adminLeaveRepository.findById(empid).get();
		  
		        
		Employee employee =restTemplate.getForObject("http://EMPLOYEE-SERVICE/employees/"+adminLeave.getEmpid(),Employee.class);
		        
		      vo.setAdminLeave(adminLeave);
		      vo.setEmployee(employee);	  
		return vo;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	public AdminLeaveImpl(AdminLeaveRepository adminLeaveRepository) {
		super();
		this.adminLeaveRepository = adminLeaveRepository;
	}

	@Override
	public AdminLeave saveAdminLeave(AdminLeave adminLeave) {
		return adminLeaveRepository.save(adminLeave);
	}

	@Override
	public List<AdminLeave> getAllLeave() {
		return adminLeaveRepository.findAll();
	}

	@Override
	public AdminLeave getLeaveById(int id) {
		return adminLeaveRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Leave", "Id", id));

	}

	@Override
	public AdminLeave updateLeave(AdminLeave adminLeave, int id) {

		AdminLeave adminLeaveDetails = adminLeaveRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Leave", "Id", id));

		adminLeaveDetails.setFrom_date(adminLeave.getFrom_date());
		adminLeaveDetails.setTo_date(adminLeave.getTo_date());
		adminLeaveDetails.setReason(adminLeave.getReason());
		adminLeaveDetails.setLeave_type(adminLeave.getLeave_type());
		adminLeaveDetails.setStatus(adminLeave.getStatus());

		adminLeaveRepository.save(adminLeaveDetails);
		return adminLeaveDetails;
	}

	@Override
	public void deleteLeave(int id) {

		adminLeaveRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Leave", "Id", id));
		adminLeaveRepository.deleteById(id);
	}

}