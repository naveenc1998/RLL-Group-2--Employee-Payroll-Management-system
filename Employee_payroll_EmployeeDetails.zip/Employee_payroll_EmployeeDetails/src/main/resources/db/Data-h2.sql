INSERT INTO epms.employees(id,emp_name,date_of_joining,gender,age,designation,email,password) VALUES(1,'Tanmay','2021-12-16','male',24,'ASE','tanmay@gmail.com','12345678'); 

INSERT INTO epms.employees(id,emp_name,date_of_joining,gender,age,designation,email,password) VALUES(2,'Ramesh','2021-11-14','male',27,'ASE','ramesh@gmail.com','87654321');  