package com.employee_payroll;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

import com.employee_payroll.domain.Employee;
import com.employee_payroll.repository.EmployeeRepository;

@EnableEurekaClient
@EnableAutoConfiguration
@SpringBootApplication
public class EmployeePayrollApplication implements CommandLineRunner {

	@Autowired
	@Qualifier("employeeRepository")
	private EmployeeRepository employeeRepository;
	public static void main(String[] args) {
		SpringApplication.run(EmployeePayrollApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		employeeRepository.save(new Employee(0,"Tanmay","2021-12-16","male",24,"ASE","tanmay@gmail.com","12345678"));
		employeeRepository.save(new Employee(0,"anil","2011-11-01","male",30,"ASE","ANIL@gmail.com","1111111111"));
		employeeRepository.save(new Employee(0,"priyanka","2013-10-06","female",20,"ASE","PRIYA@gmail.com","22222222222"));
		employeeRepository.save(new Employee(0,"sushma","2019-02-20","female",23,"ASE","SUSH@gmail.com","3333333333"));
		
	}

}
