INSERT INTO epms.admin_salary(emp_name,basic_pay,deductions,net_pay,month) VALUES('naveen','two thousand','one thousand','five thosand','feb'); 

INSERT INTO epms.admin_salary(emp_name,basic_pay,deductions,net_pay,month) VALUES('ramya','three thousand','two thousand','six thosand','jan'); 

INSERT INTO epms.admin_salary(emp_name,basic_pay,deductions,net_pay,month) VALUES('sanjan','foutr thousand','three thousand','seven thosand','march'); 

INSERT INTO epms.admin_salary(emp_name,basic_pay,deductions,net_pay,month) VALUES('suprith','five  thousand','four thousand','nine thosand','june'); 
