package com.employee_payroll.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.employee_payroll.model.AdminAttendance;
import com.employee_payroll.service.AdminAttendanceService;

import vo.ResponseTemplateVo;

@RestController


public class AdminAttendanceController {

	private AdminAttendanceService adminAttendanceService;

	public AdminAttendanceController(AdminAttendanceService adminAttendanceService) {
		super();
		this.adminAttendanceService = adminAttendanceService;
	}

	
	@GetMapping("/empWithWorkShift/{id}")
	public ResponseTemplateVo getEmpWithWorkShift(@PathVariable("id") int employeeId) {
		return adminAttendanceService.getEmpWithWorkShift(employeeId);
	}
	
	
	
	
	
	@PostMapping("/attendances")
	public ResponseEntity<AdminAttendance> saveAdminAttendance(@RequestBody AdminAttendance adminAttendance) {
		return new ResponseEntity<AdminAttendance>(adminAttendanceService.saveAdminAttendance(adminAttendance),
				HttpStatus.CREATED);
	}

	@GetMapping("/attendances")
	public List<AdminAttendance> getAllAdmins() {
		return adminAttendanceService.getAllAttendance();
	}

	@GetMapping("/attendances/{id}")
	public ResponseEntity<AdminAttendance> getAttendanceById(@PathVariable("id") int employeeId) {
		return new ResponseEntity<AdminAttendance>(adminAttendanceService.getAttendanceById(employeeId), HttpStatus.OK);
	}

		@PutMapping(value="/attendances/{id}",produces= MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<AdminAttendance> updateAttendance(@PathVariable("id") int id,
			@RequestBody AdminAttendance adminAttendance) {
		return new ResponseEntity<AdminAttendance>(adminAttendanceService.updateAttendance(adminAttendance, id),
				HttpStatus.OK);
	}
	
	
	@DeleteMapping("/attendances/{id}")
	public ResponseEntity<String> deleteAttendance(@PathVariable("id") int id) {

		adminAttendanceService.deleteAttendance(id);

		return new ResponseEntity<String>("Attendance deleted successfully!.", HttpStatus.OK);
	}

}