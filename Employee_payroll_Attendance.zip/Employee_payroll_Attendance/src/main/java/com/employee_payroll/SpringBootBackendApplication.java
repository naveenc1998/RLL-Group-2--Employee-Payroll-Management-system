
package com.employee_payroll;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

import com.employee_payroll.model.AdminAttendance;
import com.employee_payroll.repository.AdminAttendanceRepository;


@EnableEurekaClient
@EnableAutoConfiguration
@SpringBootApplication
public class SpringBootBackendApplication implements CommandLineRunner {
	
	@Autowired
	@Qualifier("adminAttendanceRepository")
	private AdminAttendanceRepository adminAttendanceRepository;
	
	
	@Bean
	@LoadBalanced
	public RestTemplate restTemplate() {
		return new RestTemplate();
		
	}
	

	public static void main(String[] args) {
		SpringApplication.run(SpringBootBackendApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		
		adminAttendanceRepository.save(new AdminAttendance(0,"naveen","rocky@gmail.com","2009-09-08","present",1));
		adminAttendanceRepository.save(new AdminAttendance(0,"raj","raj@gmail.com","2010-03-10","present",2));
		adminAttendanceRepository.save(new AdminAttendance(0,"prakesh","prakesh@gmail.com","2011-10-02","absent",3));
		adminAttendanceRepository.save(new AdminAttendance(0,"ram","ram@gmail.com","2012-12-12","absent",4));
		
	}
	
	}




