package com.employee_payroll.service;

import java.net.URI;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.client.RestTemplate;

import com.employee_payroll.exception.ResourceNotFoundException;
import com.employee_payroll.model.AdminAttendance;
import com.employee_payroll.repository.AdminAttendanceRepository;

import vo.AdminWorkSchedule;
import vo.ResponseTemplateVo;

@Service
public class AdminAttendanceImpl implements AdminAttendanceService {

	private AdminAttendanceRepository adminAttendanceRepository;
	
	@Autowired
	private RestTemplate restTemplate;

	public ResponseTemplateVo getEmpWithWorkShift(int employeeId) {
		
		  ResponseTemplateVo vo= new ResponseTemplateVo();
		  
		  AdminAttendance adminAttendance = adminAttendanceRepository.findById(employeeId).get();
		  
		        
		AdminWorkSchedule adminWorkSchedule=restTemplate.getForObject("http://ADMINWORKSCHEDULE-SERVICE/schedules/"+adminAttendance.getWsid(),AdminWorkSchedule.class);
		        
		      vo.setAdminAttendance(adminAttendance);
		      vo.setAdminWorkSchedule(adminWorkSchedule);	  
		return vo;
	}
	
	
	
	
	
	public AdminAttendanceImpl(AdminAttendanceRepository adminAttendanceRepository) {
		super();
		this.adminAttendanceRepository = adminAttendanceRepository;
	}

	@Override
	public AdminAttendance saveAdminAttendance(AdminAttendance adminAttendance) {
		return adminAttendanceRepository.save(adminAttendance);
	}

	@Override
	public List<AdminAttendance> getAllAttendance() {
		return adminAttendanceRepository.findAll();
	}

	@Override
	public AdminAttendance getAttendanceById(int id) {
		return adminAttendanceRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Attendance", "Id", id));

	}

	@Override
	public AdminAttendance updateAttendance(AdminAttendance adminAttendance, int id) {

		AdminAttendance adminAttendanceDetails = adminAttendanceRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Attendance", "Id", id));

		adminAttendanceDetails.setEmp_name(adminAttendance.getEmp_name());
		adminAttendanceDetails.setEmail(adminAttendance.getEmail());
		adminAttendanceDetails.setDate(adminAttendance.getDate());
		adminAttendanceDetails.setStatus(adminAttendance.getStatus());

		adminAttendanceRepository.save(adminAttendanceDetails);
		return adminAttendanceDetails;
	}

	@Override
	public void deleteAttendance(int id) {

		adminAttendanceRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Attendance", "Id", id));
		adminAttendanceRepository.deleteById(id);
	}

}