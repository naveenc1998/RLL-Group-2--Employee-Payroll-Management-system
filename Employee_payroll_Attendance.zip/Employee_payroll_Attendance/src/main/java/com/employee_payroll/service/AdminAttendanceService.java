package com.employee_payroll.service;

import java.util.List;

import com.employee_payroll.model.AdminAttendance;

import vo.ResponseTemplateVo;

public interface AdminAttendanceService {
	AdminAttendance saveAdminAttendance(AdminAttendance adminAttendance);

	List<AdminAttendance> getAllAttendance();

	AdminAttendance getAttendanceById(int id);

	AdminAttendance updateAttendance(AdminAttendance adminAttendance, int id);

	void deleteAttendance(int id);

	ResponseTemplateVo getEmpWithWorkShift(int employeeId);
}