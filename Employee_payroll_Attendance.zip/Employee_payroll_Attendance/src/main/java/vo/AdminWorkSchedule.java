package vo;



public class AdminWorkSchedule {

	private int wsid;
	
	private String emp_name;
	
	private String workdate;

	private String worktime;

	private String workshift;

	private String workstatus;

	public int getWsid() {
		return wsid;
	}

	public void setWsid(int wsid) {
		this.wsid = wsid;
	}

	public String getEmp_name() {
		return emp_name;
	}

	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}

	public String getWorkdate() {
		return workdate;
	}

	public void setWorkdate(String workdate) {
		this.workdate = workdate;
	}

	public String getWorktime() {
		return worktime;
	}

	public void setWorktime(String worktime) {
		this.worktime = worktime;
	}

	public String getWorkshift() {
		return workshift;
	}

	public void setWorkshift(String workshift) {
		this.workshift = workshift;
	}

	public String getWorkstatus() {
		return workstatus;
	}

	public void setWorkstatus(String workstatus) {
		this.workstatus = workstatus;
	}

	public AdminWorkSchedule(int wsid, String emp_name, String workdate, String worktime, String workshift,
			String workstatus) {
		super();
		this.wsid = wsid;
		this.emp_name = emp_name;
		this.workdate = workdate;
		this.worktime = worktime;
		this.workshift = workshift;
		this.workstatus = workstatus;
	}

	public AdminWorkSchedule() {
		super();
		
	}

	@Override
	public String toString() {
		return "AdminWorkSchedule [wsid=" + wsid + ", emp_name=" + emp_name + ", workdate=" + workdate + ", worktime="
				+ worktime + ", workshift=" + workshift + ", workstatus=" + workstatus + "]";
	}

	
	
	
	
}
