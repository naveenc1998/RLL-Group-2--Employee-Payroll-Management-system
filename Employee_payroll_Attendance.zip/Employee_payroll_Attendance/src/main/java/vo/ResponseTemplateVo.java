package vo;

import com.employee_payroll.model.AdminAttendance;

public class ResponseTemplateVo {
   
	private AdminWorkSchedule adminWorkSchedule;
	
	private AdminAttendance adminAttendance;

	public AdminWorkSchedule getAdminWorkSchedule() {
		return adminWorkSchedule;
	}

	public void setAdminWorkSchedule(AdminWorkSchedule adminWorkSchedule) {
		this.adminWorkSchedule = adminWorkSchedule;
	}

	public AdminAttendance getAdminAttendance() {
		return adminAttendance;
	}

	public void setAdminAttendance(AdminAttendance adminAttendance) {
		this.adminAttendance = adminAttendance;
	}

	public ResponseTemplateVo(AdminWorkSchedule adminWorkSchedule, AdminAttendance adminAttendance) {
		super();
		this.adminWorkSchedule = adminWorkSchedule;
		this.adminAttendance = adminAttendance;
	}

	public ResponseTemplateVo() {
		super();
	}

	@Override
	public String toString() {
		return "ResponseTemplateVo [adminWorkSchedule=" + adminWorkSchedule + ", adminAttendance=" + adminAttendance
				+ "]";
	}
	
	
}
