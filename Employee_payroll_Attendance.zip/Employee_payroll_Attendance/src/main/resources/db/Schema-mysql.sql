USE emps;  

DROP TABLE IF EXISTS admin_attendance ; 

CREATE TABLE `admin_attendance` (
  `id` INT NOT NULL AUTO_INCREMENT,
    `emp_name` varchar(255) DEFAULT NULL,
      `email` varchar(255) DEFAULT NULL,
  `date` DATE DEFAULT NULL,


  `status` varchar(255) DEFAULT NULL,  
 
 wsid INT
);

