
INSERT INTO `epms`.`admin_attendence` (`id`,`emp_name`,  `email`,'date',`status`, 'wsid') VALUES ('raskesh', 'rakesh@gmail.com', '2002-03-01', 'working',1);

INSERT INTO `epms`.`admin_attendence` (`id`,`emp_name`,  `email`,'date',`status`, 'wsid') VALUES ('raj', 'raj@gmail.com', '2002-09-10', 'working',2);

